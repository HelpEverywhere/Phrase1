﻿/// <reference path="../typings/jquery/jquery.d.ts" />
/// <reference path="../typings/angularjs/angular.d.ts" />
/// <reference path="services/appstorage.ts" />
/// <reference path="controllers/appctrl.ts" />
/// <reference path="directives/changename.ts" />
/// <reference path="modules/app.ts" />
