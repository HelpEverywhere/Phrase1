﻿/// <reference path="../_app.ts" />
module app {
    'use strict';
    export function changeName(): ng.IDirective {
        return {
            restrict: 'A',
            scope: false, // use controller scope
            link: ($scope: IAppCtrlScope, element: JQuery) => {
                element.on('mouseenter', () => {
                        element.addClass('animate');
                    })
                    .on('mouseleave', () => {
                        element.removeClass('animate');
                    })
                    .on('click', () => {
                    var name = JSON.parse(JSON.stringify(prompt('Please Enter your name:'))); // encode input
                    $scope.changeName(name);
                    $scope.$digest();
                });
            }
        }
    };
}