﻿namespace ReportViewerForMvc.Example.Reports {
    
    
    public partial class dsLocalReport {
    }
}
