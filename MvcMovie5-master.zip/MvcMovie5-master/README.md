# MVC5movie
Sample application for the tutorial [Getting Started with ASP.NET MVC 5](http://www.asp.net/mvc/overview/getting-started/introduction/getting-started) at the http://www.asp.net site.

You can deploy the project to your Azure account.

[![Deploy to Azure](http://azuredeploy.net/deploybutton.png)](https://azuredeploy.net/)





